

from PyQt5 import QtCore, QtGui, QtWidgets
import cv2,sys
from PyQt5.QtCore import QTimer
from PyQt5.QtGui import QImage, QPixmap


class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(1300, 800)
        MainWindow.setMinimumSize(QtCore.QSize(1280, 720))
        MainWindow.setStyleSheet("")
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.gridLayout = QtWidgets.QGridLayout(self.centralwidget)
        self.gridLayout.setObjectName("gridLayout")
        self.DisplayLabel = QtWidgets.QLabel(self.centralwidget)
        self.DisplayLabel.setMinimumSize(QtCore.QSize(0, 0))
        self.DisplayLabel.setStyleSheet("QLabel{border:2px solid ;}")
        self.DisplayLabel.setText("")
        self.DisplayLabel.setObjectName("DisplayLabel")
        self.gridLayout.addWidget(self.DisplayLabel, 0, 0, 1, 4)
        self.Close = QtWidgets.QPushButton(self.centralwidget)
        self.Close.setObjectName("Close")
        self.gridLayout.addWidget(self.Close, 2, 3, 1, 1)
        self.Open = QtWidgets.QPushButton(self.centralwidget)
        self.Open.setObjectName("Open")
        self.gridLayout.addWidget(self.Open, 2, 2, 1, 1)
        self.radioButtonFile = QtWidgets.QRadioButton(self.centralwidget)
        self.radioButtonFile.setObjectName("radioButtonFile")
        self.gridLayout.addWidget(self.radioButtonFile, 2, 1, 1, 1)
        self.radioButtonCam = QtWidgets.QRadioButton(self.centralwidget)
        self.radioButtonCam.setObjectName("radioButtonCam")
        self.gridLayout.addWidget(self.radioButtonCam, 1, 1, 1, 1)
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 1300, 26))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.Close.setText(_translate("MainWindow", "Close"))
        self.Open.setText(_translate("MainWindow", "Open"))
        self.radioButtonFile.setText(_translate("MainWindow", "视频"))
        self.radioButtonCam.setText(_translate("MainWindow", "相机"))




